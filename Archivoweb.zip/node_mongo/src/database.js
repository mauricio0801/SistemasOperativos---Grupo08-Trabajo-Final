const mongoose=require("mongoose");

//env prod

//mongoose.connect("mongodb://database/mydatabase")


//env dev
mongoose.connect("mongodb://localhost:27019/Hp")

.then(db=>console.log("DB is conected to",db.connection.host))
.catch(err=>console.error(err))
