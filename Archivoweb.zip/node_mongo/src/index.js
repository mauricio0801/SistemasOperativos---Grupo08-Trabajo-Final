const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const app = express();
const PORT = 3001;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "/views"));

require("./database");

// Utiliza las rutas de nroutes.js y hroutes.js
const nRoutes = require("./routes/nroutes.js");
// Agrega más rutas según sea necesario
// const hRoutes = require("./routes/hroutes.js");

app.use(nRoutes);
// Agrega más rutas según sea necesario
// app.use(hRoutes);

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// Manejo de errores con tres parámetros (err, req, res)
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Error en index.js del servidor');
});
