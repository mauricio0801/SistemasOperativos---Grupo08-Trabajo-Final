// controllers/hospitalesController.js
const ModelHospital = require("../models/hospitalModel");

// Mostrar la lista de hospitales
exports.mostrarHospitales = async (req, res) => {
    try {
        // Obtener la lista de hospitales desde la base de datos
        const hospitales = await ModelHospital.find({});
        
        // Renderizar la vista de hospitales y pasar la lista de hospitales como datos
        res.render("hospitales", { hospitales });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

// Mostrar el formulario para crear un nuevo hospital
exports.mostrarFormularioCrear = (req, res) => {
    res.render("crearHospital");
};

// Crear un nuevo hospital en la base de datos
exports.crearHospital = async (req, res) => {
    try {
        const { nombre, direccion } = req.body;

        // Crear un nuevo objeto Hospital con los datos del formulario
        const nuevoHospital = new ModelHospital({
            nombre,
            direccion,
        });

        // Guardar el nuevo hospital en la base de datos
        await nuevoHospital.save();

        // Redirigir a la lista de hospitales después de crear uno nuevo
        res.redirect("/hospitales");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

// Mostrar el formulario para editar un hospital
exports.mostrarFormularioEditar = async (req, res) => {
    try {
        const idHospital = req.params.id;
        const hospital = await ModelHospital.findById(idHospital);

        if (!hospital) {
            // Manejar el caso en el que el hospital no se encuentre
            return res.status(404).send("Hospital no encontrado");
        }

        // Renderizar el formulario de edición con los datos del hospital
        res.render("editarHospital", { hospital });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

// Actualizar un hospital en la base de datos
exports.actualizarHospital = async (req, res) => {
    try {
        const idHospital = req.params.id;
        const { nombre, direccion } = req.body;

        // Actualizar el hospital en la base de datos
        const hospitalActualizado = await ModelHospital.findByIdAndUpdate(
            idHospital,
            { nombre, direccion },
            { new: true } // Devolver la versión actualizada del hospital
        );

        if (!hospitalActualizado) {
            // Manejar el caso en el que el hospital no se actualice correctamente
            return res.status(404).send("No se pudo actualizar el hospital");
        }

        // Redirigir a la lista de hospitales después de editar uno
        res.redirect("/hospitales");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

// Borrar un hospital de la base de datos
exports.borrarHospital = async (req, res) => {
    try {
        const idHospital = req.params.id;

        // Borrar el hospital de la base de datos
        await ModelHospital.findByIdAndDelete(idHospital);

        // Redirigir a la lista de hospitales después de borrar uno
        res.redirect("/hospitales");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};
