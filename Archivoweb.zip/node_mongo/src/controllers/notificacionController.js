const ModelNotificacion = require("../models/notificacion");

exports.mostrarNotificaciones = async (req, res) => {
    try {
        // Obtener la lista de notificaciones desde la base de datos
        const notificaciones = await ModelNotificacion.find({});

        // Renderizar la vista de notificaciones y pasar la lista de notificaciones como datos
        res.render("notificaciones", { notificaciones });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

exports.mostrarFormularioCrear = (req, res) => {
    res.render("crearNotificacion");
};

exports.crearNotificacion = async (req, res) => {
    try {
        const { usuario_id, mensaje, visto } = req.body;

        // Crear una nueva notificación con los datos del formulario
        const nuevaNotificacion = new ModelNotificacion({
            usuario_id,
            mensaje,
            visto: visto === 'on', // Convertir a booleano
        });

        // Guardar la nueva notificación en la base de datos
        await nuevaNotificacion.save();

        // Redirigir a la lista de notificaciones después de crear una nueva
        res.redirect("/notificaciones");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

exports.mostrarFormularioEditar = async (req, res) => {
    try {
        const idNotificacion = req.params.id;
        const notificacion = await ModelNotificacion.findById(idNotificacion);

        if (!notificacion) {
            // Manejar el caso en el que la notificación no se encuentre
            return res.status(404).send("Notificación no encontrada");
        }

        // Renderizar el formulario de edición con los datos de la notificación
        res.render("editarNotificacion", { notificacion });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

exports.actualizarNotificacion = async (req, res) => {
    try {
        const idNotificacion = req.params.id;
        const { usuario_id, mensaje, visto } = req.body;

        // Actualizar la notificación en la base de datos
        const notificacionActualizada = await ModelNotificacion.findByIdAndUpdate(
            idNotificacion,
            { usuario_id, mensaje, visto: visto === 'on' }, // Convertir a booleano
            { new: true } // Devolver la versión actualizada de la notificación
        );

        if (!notificacionActualizada) {
            // Manejar el caso en el que la notificación no se actualice correctamente
            return res.status(404).send("No se pudo actualizar la notificación");
        }

        // Redirigir a la lista de notificaciones después de editar una
        res.redirect("/notificaciones");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

exports.borrarNotificacion = async (req, res) => {
    try {
        const idNotificacion = req.params.id;

        // Borrar la notificación de la base de datos
        const resultado = await ModelNotificacion.findOneAndDelete({ _id: idNotificacion });

        if (!resultado) {
            return res.status(404).send("No se pudo borrar la notificación");
        }

        // Redirigir a la lista de notificaciones después de borrar una
        res.redirect("/notificaciones");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};
