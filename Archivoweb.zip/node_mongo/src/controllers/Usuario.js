// controllers/indexController.js
const ModelUsuario = require("../models/userModel");
const ModelPublicacion = require("../models/publicacion");

exports.mostrar = async (req, res) => {
    try {
        // Obtén la lista de usuarios y publicaciones desde la base de datos
        const usuarios = await ModelUsuario.find({});
        const publicaciones = await ModelPublicacion.find({});

        // Renderiza la vista y pasa ambas listas como datos
        res.render("index", { usuarios, publicaciones });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el contralador");
    }
};

exports.borrarPublicacion = async (req, res) => {
    try {
        const idPublicacion = req.params.id;

        // Borrar la publicación de la base de datos
        const resultado = await ModelPublicacion.findByIdAndDelete(idPublicacion);

        if (!resultado) {
            // Manejar el caso en el que la publicación no se encuentre
            return res.status(404).send("Publicación no encontrada");
        }

        // Redirigir a la página principal o a donde desees después de borrar
        res.redirect("/");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador: " + error.message);
    }
};
