const ModelPublicacion = require("../models/publicacion");


module.exports.mostrarEditarPublicacion = async (req, res) => {
    try {
        const idPublicacion = req.params.id;
       
        const publicacion = await ModelPublicacion.findById(idPublicacion);

        if (!publicacion) {
            // Manejar el caso en el que la publicación no se encuentre
            return res.status(404).send("Publicación no encontrada");
        }

        // Renderizar el formulario de edición con los datos de la publicación
        res.render("editarPublicacion", { publicacion });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};
module.exports.editarPublicacion = async (req, res) => {
    try {
        const idPublicacion = req.params.id;
        const { contenido } = req.body;

        console.log("ID de la publicación:", idPublicacion);
        console.log("Contenido nuevo:", contenido);
        console.log(req.body);  // Agrega esta línea

       // Actualizar la publicación en la base de datos
       const publicacionActualizada = await ModelPublicacion.findByIdAndUpdate(
        idPublicacion,
        { contenido },
        { new: true } // Devolver la versión actualizada de la publicación
    );

    

    // Redirigir a la página principal o a donde desees después de editar
    res.redirect("/");
} catch (error) {
    console.error(error);
    res.status(500).send("Error en el controlador");
}
};

exports.borrarPublicacion = async (req, res) => {
    try {
        const idPublicacion = req.params.id;

        // Borrar la publicación de la base de datos
        await ModelPublicacion.findByIdAndRemove(idPublicacion);

        // Redirigir a la página principal o a donde desees después de borrar
        res.redirect("/");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};


exports.mostrarCrearPublicacion = (req, res) => {
    // Renderizar el formulario para la creación de publicación
    res.render("crearPublicacion");
};

exports.crearPublicacion = async (req, res) => {
    try {
        const { autor_id, contenido } = req.body;

        // Crear una nueva publicación en la base de datos
        await ModelPublicacion.create({ autor_id, contenido });

        // Redirigir a la página principal o a donde desees después de crear
        res.redirect("/");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador: " + error.message);
    }
};