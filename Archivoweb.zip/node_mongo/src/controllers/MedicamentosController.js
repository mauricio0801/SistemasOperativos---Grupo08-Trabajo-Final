const Medicamento = require("../models/medicamento");

// Mostrar la lista de medicamentos
exports.mostrarMedicamentos = async (req, res) => {
    try {
      // Obtener la lista de medicamentos desde la base de datos
      const medicamentos = await Medicamento.find({});
      
      // Renderizar la vista de medicamentos y pasar la lista de medicamentos como datos
      res.render("medicamentos", { medicamentos });
    } catch (error) {
      console.error(error);
      res.status(500).send("Error en el controlador");
    }
  };
// Mostrar el formulario para crear un nuevo medicamento
exports.mostrarFormularioCrear = (req, res) => {
  res.render("crearMedicamento");
};

// Crear un nuevo medicamento en la base de datos
exports.crearMedicamento = async (req, res) => {
  try {
    const { nombre, stock, fecha, codigoBarras, tags } = req.body;

    // Crear un nuevo objeto Medicamento con los datos del formulario
    const nuevoMedicamento = new Medicamento({
      nombre,
      stock,
      fecha,
      codigoBarras,
      tags,
    });

    // Guardar el nuevo medicamento en la base de datos
    await nuevoMedicamento.save();

    // Redirigir a la lista de medicamentos después de crear uno nuevo
    res.redirect("/medicamentos");
  } catch (error) {
    console.error(error);
    res.status(500).send("Error en el controlador");
  }
};

// Mostrar el formulario para editar un medicamento
exports.mostrarFormularioEditar = async (req, res) => {
  try {
    const idMedicamento = req.params.id;
    const medicamento = await Medicamento.findById(idMedicamento);

    if (!medicamento) {
      // Manejar el caso en el que el medicamento no se encuentre
      return res.status(404).send("Medicamento no encontrado");
    }

    // Renderizar el formulario de edición con los datos del medicamento
    res.render("editarMedicamento", { medicamento });
  } catch (error) {
    console.error(error);
    res.status(500).send("Error en el controlador");
  }
};

// Actualizar un medicamento en la base de datos
exports.actualizarMedicamento = async (req, res) => {
  try {
    const idMedicamento = req.params.id;
    const { nombre, stock, fecha, codigoBarras, tags } = req.body;

    // Actualizar el medicamento en la base de datos
    const medicamentoActualizado = await Medicamento.findByIdAndUpdate(
      idMedicamento,
      { nombre, stock, fecha, codigoBarras, tags },
      { new: true } // Devolver la versión actualizada del medicamento
    );

    if (!medicamentoActualizado) {
      // Manejar el caso en el que el medicamento no se actualice correctamente
      return res.status(404).send("No se pudo actualizar el medicamento");
    }

    // Redirigir a la lista de medicamentos después de editar uno
    res.redirect("/medicamentos");
  } catch (error) {
    console.error(error);
    res.status(500).send("Error en el controlador");
  }
};

// Borrar un medicamento de la base de datos
exports.borrarMedicamento = async (req, res) => {
  try {
    const idMedicamento = req.params.id;

    // Borrar el medicamento de la base de datos utilizando findOneAndDelete
    const resultado = await Medicamento.findOneAndDelete({ _id: idMedicamento });

    if (!resultado) {
      // Manejar el caso en el que el medicamento no se encuentre
      return res.status(404).send("Medicamento no encontrado");
    }

    // Redirigir a la lista de medicamentos después de borrar uno
    res.redirect("/medicamentos");
  } catch (error) {
    console.error(error);
    res.status(500).send("Error en el controlador");
  }
};
