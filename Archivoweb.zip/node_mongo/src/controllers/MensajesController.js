// controllers/MensajesController.js

const ModelMessage = require("../models/mensaje");

exports.mostrarMensajes = async (req, res) => {
    try {
        const mensajes = await ModelMessage.find({});
        res.render("mensaje", { mensajes });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

exports.mostrarFormularioEditar = async (req, res) => {
    try {
        const idMensaje = req.params.id;
        const mensaje = await ModelMessage.findById(idMensaje);

        if (!mensaje) {
            return res.status(404).send("Mensaje no encontrado");
        }

        res.render("editarmensaje", { mensaje });
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el cuntrolador");
    }
};

exports.actualizarMensaje = async (req, res) => {
    try {
        const idMensaje = req.params.id;
        const { remitente_id, destinatario_id, contenido } = req.body;

        const mensajeActualizado = await ModelMessage.findByIdAndUpdate(
            idMensaje,
            { remitente_id, destinatario_id, contenido },
            { new: true }
        );

        if (!mensajeActualizado) {
            return res.status(404).send("No se pudo actualizar el mensaje");
        }

        res.redirect("/mensaje");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};


exports.borrarMensaje = async (req, res) => {
    try {
        const idMensaje = req.params.id;

        // Borra el mensaje de la base de datos
        const resultado = await ModelMessage.findOneAndDelete({ _id: idMensaje });

        if (!resultado) {
            return res.status(404).send("No se pudo borrar el mensaje");
        }

        // Redirige a la lista de mensajes después de borrar uno
        res.redirect("/mensaje");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el centrolador");
    }
};

exports.crearMensaje = async (req, res) => {
    try {
        const { remitente, destinatario, contenido } = req.body;

        // Crea un nuevo mensaje con los datos del formulario
        const nuevoMensaje = new ModelMessage({
            remitente_id: remitente,
            destinatario_id: destinatario,
            contenido: contenido
        });

        // Guarda el nuevo mensaje en la base de datos
        await nuevoMensaje.save();

        // Redirige a la lista de mensajes después de crear uno nuevo
        res.redirect("/mensaje");
    } catch (error) {
        console.error(error);
        res.status(500).send("Error en el controlador");
    }
};

  exports.mostrarFormularioCrear = (req, res) => {
    // Puedes personalizar esta vista según tus necesidades
    res.render("crearMensaje");
  };