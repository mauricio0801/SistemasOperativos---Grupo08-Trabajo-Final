const express = require("express")
const router = express.Router()

const UsuarioController = require ("../controllers/Usuario")
const PublicacionController = require("../controllers/PublicacionController");
const MedicamentoController = require("../controllers/MedicamentosController");
const hospitalesController = require("../controllers/hospitalesController");
const mensajesController = require("../controllers/MensajesController");
const notificacionesController = require("../controllers/notificacionController");


router.get("/",UsuarioController.mostrar)

router.post("/publicaciones/editar/:id", PublicacionController.editarPublicacion);

router.post("/publicaciones/borrar/:id", UsuarioController.borrarPublicacion);

router.get("/publicaciones/editar/:id", PublicacionController.mostrarEditarPublicacion);

router.get("/publicaciones/crear", PublicacionController.mostrarCrearPublicacion);
router.post("/publicaciones/crear", PublicacionController.crearPublicacion);

// Ruta para mostrar la lista de medicamentos
router.get("/medicamentos", MedicamentoController.mostrarMedicamentos);

// Mostrar el formulario para crear un nuevo medicamento
router.get("/medicamentos/crear", MedicamentoController.mostrarFormularioCrear);

// Crear un nuevo medicamento en la base de datos
router.post("/medicamentos/crear", MedicamentoController.crearMedicamento);

// Mostrar el formulario para editar un medicamento
router.get("/medicamentos/editar/:id", MedicamentoController.mostrarFormularioEditar);

// Actualizar un medicamento en la base de datos
router.post("/medicamentos/editar/:id", MedicamentoController.actualizarMedicamento);

// Borrar un medicamento de la base de datos
router.post("/medicamentos/borrar/:id", MedicamentoController.borrarMedicamento);


router.get("/hospitales", hospitalesController.mostrarHospitales);
router.get("/hospitales/crear", hospitalesController.mostrarFormularioCrear);
router.post("/hospitales/crear", hospitalesController.crearHospital);
router.get("/hospitales/editar/:id", hospitalesController.mostrarFormularioEditar);
router.post("/hospitales/editar/:id", hospitalesController.actualizarHospital);
router.post("/hospitales/borrar/:id", hospitalesController.borrarHospital);


router.get("/mensaje", mensajesController.mostrarMensajes);
router.get("/mensaje/editar/:id", mensajesController.mostrarFormularioEditar);
router.post("/mensaje/editar/:id", mensajesController.actualizarMensaje);
router.post("/mensaje/borrar/:id", mensajesController.borrarMensaje);
router.get("/mensaje/crear", mensajesController.mostrarFormularioCrear);  // Nueva línea
router.post("/mensaje/crear", mensajesController.crearMensaje);  // Nueva línea

// Ruta para mostrar la lista de notificaciones
router.get("/notificaciones", notificacionesController.mostrarNotificaciones);

// Mostrar el formulario para crear una nueva notificación
router.get("/notificaciones/crear", notificacionesController.mostrarFormularioCrear);
router.post("/notificaciones/crear", notificacionesController.crearNotificacion);

// Mostrar el formulario para editar una notificación
router.get("/notificaciones/editar/:id", notificacionesController.mostrarFormularioEditar);
router.post("/notificaciones/editar/:id", notificacionesController.actualizarNotificacion);

// Borrar una notificación de la base de datos
router.post("/notificaciones/borrar/:id", notificacionesController.borrarNotificacion);

module.exports = router;

