const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
    nombre: { type: String },
    email: { type: String },
    direccion: { type: String },
    edad: {type:Number}
  }, {
    timestamps: true, 
    versionKey: false
  });
  

const ModelUser = mongoose.model("usuario",userSchema)

module.exports = ModelUser;