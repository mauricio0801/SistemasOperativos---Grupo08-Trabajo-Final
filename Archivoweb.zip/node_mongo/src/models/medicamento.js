const mongoose = require('mongoose');

const medicamentoSchema = new mongoose.Schema({
    nombre: { type: String },
    stock: { type: Number },
    fecha: { type: Date },
    codigoBarras: { type: String },
    tags: [{ type: String }]
  }, {
    timestamps: true, 
    versionKey: false
  });

const Medicamento = mongoose.model("medicamento", medicamentoSchema);

module.exports = Medicamento;
