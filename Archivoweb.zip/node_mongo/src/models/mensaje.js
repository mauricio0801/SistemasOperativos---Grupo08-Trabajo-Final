const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  remitente_id: { type: String },
  destinatario_id: { type: String },
  contenido: { type: String }
}, {
  timestamps: true,
  versionKey: false
});

const ModelMessage = mongoose.model("mensaje", messageSchema);

module.exports = ModelMessage;
