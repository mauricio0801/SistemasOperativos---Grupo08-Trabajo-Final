const mongoose = require('mongoose');

const notificacionSchema = new mongoose.Schema({
    usuario_id: { type: String, required: true },
    mensaje: { type: String, required: true },
    visto: { type: Boolean, default: false }
  }, {
    timestamps: true, 
    versionKey: false
  });
  
const ModelNotificacion = mongoose.model("notificacion", notificacionSchema)

module.exports = ModelNotificacion;
