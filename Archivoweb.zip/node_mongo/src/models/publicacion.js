const mongoose = require('mongoose');

const publicacionSchema = new mongoose.Schema({
  autor_id: { type: String, required: true },
  contenido: { type: String, required: true },
  likes: { type: Number, default: 0 }
}, {
  timestamps: true,
  versionKey: false
});

const PublicacionModel = mongoose.model("Publicacion", publicacionSchema);

module.exports = PublicacionModel;
