const mongoose = require('mongoose');

const hospitalSchema = new mongoose.Schema({
  nombre: { type: String },
  direccion: { type: String }
}, {
  timestamps: true,
  versionKey: false
});

const ModelHospital = mongoose.model("Hospital", hospitalSchema);

module.exports = ModelHospital;
